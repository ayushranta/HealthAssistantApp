package com.example.healthasistence.auth;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;
import com.example.healthasistence.main.MainMenuActivity;

import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {
    EditText email, password;
    Button loginBtn, registerBtn;
    DBHelper db;
    SharedPreferences sharedPreferences;

    // Validation patterns
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@(.+)$"
    );
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(
            "^.{6,}$" // Minimum 6 characters
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        registerBtn = findViewById(R.id.registerBtn);
        db = new DBHelper(this);

        // Initialize SharedPreferences for session management
        sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);

        // Login button click
        loginBtn.setOnClickListener(v -> {
            String em = email.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Validation
            if (em.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isValidEmail(em)) {
                email.setError("Please enter a valid email address");
                return;
            }

            if (!isValidPassword(pass)) {
                password.setError("Password must be at least 6 characters long");
                return;
            }

            int userId = db.checkUser(em, pass);
            if (userId != -1) {
                // Save user session
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("user_id", userId);
                editor.putString("user_email", em);
                editor.apply();

                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                // Go to MainMenuActivity after login
                Intent intent = new Intent(LoginActivity.this, MainMenuActivity.class);
                startActivity(intent);
                finish(); // close login screen
            } else {
                Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Register button click
        registerBtn.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    // Email validation method
    private boolean isValidEmail(String email) {
        if (email == null) return false;
        return EMAIL_PATTERN.matcher(email).matches();
    }

    // Password validation method
    private boolean isValidPassword(String password) {
        if (password == null) return false;
        return PASSWORD_PATTERN.matcher(password).matches();
    }
}