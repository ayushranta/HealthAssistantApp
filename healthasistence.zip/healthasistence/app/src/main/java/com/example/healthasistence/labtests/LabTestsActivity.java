package com.example.healthasistence.labtests;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;

import java.util.ArrayList;

public class LabTestsActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<LabTestModel> labTestList;
    LabTestAdapter adapter;
    ImageView backBtn;
    LinearLayout cartBtn;
    TextView cartBadge, cartItemCount;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_tests);

        // Initialize views
        recyclerView = findViewById(R.id.labTestsRecycler);
        backBtn = findViewById(R.id.backBtn);
        cartBtn = findViewById(R.id.cartBtn);
        cartBadge = findViewById(R.id.cartBadge);
        cartItemCount = findViewById(R.id.cartItemCount);
        db = new DBHelper(this);

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Update cart info
        updateCartInfo();

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Cart button click
        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LabTestsActivity.this, CartActivity.class));
            }
        });

        // Populate lab test list
        labTestList = new ArrayList<>();
        labTestList.add(new LabTestModel("Full Body Checkup", "Complete health screening with 60+ tests including blood count, liver, kidney, thyroid, and diabetes screening", "1500", R.drawable.fullbody));
        labTestList.add(new LabTestModel("Blood Test", "Basic blood analysis including CBC, hemoglobin, blood sugar, and cholesterol levels", "500", R.drawable.blood));
        labTestList.add(new LabTestModel("Diabetes Test", "Comprehensive diabetes screening with fasting blood sugar, HbA1c, and glucose tolerance test", "300", R.drawable.diabetes));
        labTestList.add(new LabTestModel("Thyroid Profile", "Complete thyroid function test including T3, T4, and TSH levels", "600", R.drawable.thyroid));
        labTestList.add(new LabTestModel("Liver Function Test", "Liver health assessment with SGOT, SGPT, bilirubin, and protein levels", "400", R.drawable.liver));
        labTestList.add(new LabTestModel("Kidney Function Test", "Kidney health screening with creatinine, urea, and electrolyte levels", "350", R.drawable.kidney));
        labTestList.add(new LabTestModel("Cardiac Risk Markers", "Heart health assessment with lipid profile and cardiac enzyme tests", "800", R.drawable.ic_healthcare_logo));
        labTestList.add(new LabTestModel("Vitamin Panel", "Comprehensive vitamin deficiency test including Vitamin D, B12, and iron levels", "1200", R.drawable.vitamin));

        adapter = new LabTestAdapter(this, labTestList);
        recyclerView.setAdapter(adapter);
    }

    private void updateCartInfo() {
        // Get current user ID from session
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        int currentUserId = sharedPreferences.getInt("user_id", -1);

        if (currentUserId == -1) {
            // User not logged in, show empty cart
            cartItemCount.setText("0 items");
            cartBadge.setVisibility(View.GONE);
            return;
        }

        Cursor cursor = db.getCartItems(currentUserId);
        int itemCount = cursor != null ? cursor.getCount() : 0;
        if (cursor != null) {
            cursor.close();
        }

        // Update cart item count text
        if (itemCount == 1) {
            cartItemCount.setText("1 item");
        } else {
            cartItemCount.setText(itemCount + " items");
        }

        // Update cart badge
        if (itemCount > 0) {
            cartBadge.setText(String.valueOf(itemCount));
            cartBadge.setVisibility(View.VISIBLE);
        } else {
            cartBadge.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartInfo();
    }
}