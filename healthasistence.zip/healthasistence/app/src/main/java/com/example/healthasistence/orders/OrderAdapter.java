package com.example.healthasistence.orders;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {

    Context context;
    ArrayList<OrderModel> list;
    String orderType;
    DBHelper db;
    int currentUserId;

    public OrderAdapter(Context context, ArrayList<OrderModel> list, String orderType, DBHelper db, int currentUserId) {
        this.context = context;
        this.list = list;
        this.orderType = orderType;
        this.db = db;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        OrderModel model = list.get(position);

        if ("APPOINTMENT".equals(model.getType())) {
            holder.orderType.setText("Doctor Appointment");
            holder.doctorName.setText("Dr. " + model.getDoctorName());
            holder.specialization.setText(model.getSpecialization());
            holder.patientName.setText("Patient: " + model.getPatientName());
            holder.dateTime.setText("On " + model.getDate() + " at " + model.getTime());
            holder.fee.setText("Fee: " + model.getFee());
        } else {
            holder.orderType.setText("Lab Test");
            holder.doctorName.setText(model.getDoctorName());
            holder.specialization.setText(model.getSpecialization());
            holder.patientName.setText("Patient: " + model.getPatientName());
            holder.dateTime.setText(model.getDate());
            holder.fee.setText(model.getFee());
        }

        // Cancel button click
        holder.cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Remove from database first
                boolean removed = removeFromDatabase(model, position);
                if (removed) {
                    // Remove from list
                    list.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, list.size());
                    Toast.makeText(context, "Order canceled", Toast.LENGTH_SHORT).show();

                    // Refresh the parent activity to update sections
                    if (context instanceof OrdersActivity) {
                        ((OrdersActivity) context).loadOrders();
                    }
                } else {
                    Toast.makeText(context, "Failed to cancel order", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Complete button click
        holder.completeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Remove from database first
                boolean removed = removeFromDatabase(model, position);
                if (removed) {
                    // Remove from list
                    list.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, list.size());
                    Toast.makeText(context, "Order marked as completed", Toast.LENGTH_SHORT).show();

                    // Refresh the parent activity to update sections
                    if (context instanceof OrdersActivity) {
                        ((OrdersActivity) context).loadOrders();
                    }
                } else {
                    Toast.makeText(context, "Failed to complete order", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean removeFromDatabase(OrderModel model, int position) {
        if ("APPOINTMENT".equals(model.getType())) {
            // Remove from appointments table for current user
            return db.removeAppointment(model.getPatientName(), model.getDoctorName(),
                    model.getDate(), model.getTime(), currentUserId);
        } else {
            // Remove from lab_orders table for current user
            return db.removeLabOrder(model.getPatientName(), model.getDoctorName(), currentUserId);
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView orderType, doctorName, specialization, patientName, dateTime, fee;
        Button cancelBtn, completeBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            orderType = itemView.findViewById(R.id.orderType);
            doctorName = itemView.findViewById(R.id.orderDoctorName);
            specialization = itemView.findViewById(R.id.orderSpecialization);
            patientName = itemView.findViewById(R.id.orderPatientName);
            dateTime = itemView.findViewById(R.id.orderDateTime);
            fee = itemView.findViewById(R.id.orderFee);
            cancelBtn = itemView.findViewById(R.id.cancelBtn);
            completeBtn = itemView.findViewById(R.id.completeBtn);
        }
    }
}