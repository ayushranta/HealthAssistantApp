package com.example.healthasistence.auth;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;
import com.example.healthasistence.main.MainMenuActivity;

import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {
    EditText name, email, password;
    Button registerBtn;
    DBHelper db;
    SharedPreferences sharedPreferences;

    // Validation patterns
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@(.+)$"
    );
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(
            "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"
    );
    private static final Pattern NAME_PATTERN = Pattern.compile(
            "^[a-zA-Z ]{2,30}$"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        registerBtn = findViewById(R.id.registerBtn);
        db = new DBHelper(this);

        sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);

        registerBtn.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String em = email.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Basic empty field validation
            if (n.isEmpty() || em.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Name validation
            if (!isValidName(n)) {
                name.setError("Name should contain only letters and spaces (2-30 characters)");
                return;
            }

            // Email validation
            if (!isValidEmail(em)) {
                email.setError("Please enter a valid email address");
                return;
            }

            // Password validation
            if (!isValidPassword(pass)) {
                password.setError("Password must contain:\n• 8+ characters\n• 1 uppercase letter\n• 1 lowercase letter\n• 1 number\n• 1 special character");
                return;
            }

            long userId = db.insertUser(n, em, pass);
            if (userId != -1) {
                // Save user session
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("user_id", (int) userId);
                editor.putString("user_email", em);
                editor.apply();

                Toast.makeText(this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(RegisterActivity.this, MainMenuActivity.class));
                finish();
            } else {
                Toast.makeText(this, "User already exists!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Email validation method
    private boolean isValidEmail(String email) {
        if (email == null) return false;
        return EMAIL_PATTERN.matcher(email).matches();
    }

    // Password validation method (Strong password)
    private boolean isValidPassword(String password) {
        if (password == null) return false;
        return PASSWORD_PATTERN.matcher(password).matches();
    }

    // Name validation method
    private boolean isValidName(String name) {
        if (name == null) return false;
        return NAME_PATTERN.matcher(name).matches();
    }
}