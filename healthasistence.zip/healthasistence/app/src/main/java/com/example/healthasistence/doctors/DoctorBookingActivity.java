package com.example.healthasistence.doctors;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class DoctorBookingActivity extends AppCompatActivity {
    TextView doctorName, specialization, fee, selectedDateText, selectedTimeText;
    EditText patientName, patientPhone;
    Button confirmBtn, selectDateBtn;
    ImageView backBtn;
    LinearLayout timeSlotsLayout;
    DBHelper db;

    private String selectedDate = "";
    private String selectedTime = "";
    private String currentDoctorName = "";
    private Calendar calendar;
    private List<Button> timeSlotButtons = new ArrayList<>();

    // Validation patterns
    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z ]{2,30}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^[6-9]\\d{9}$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_booking);

        // Initialize views
        doctorName = findViewById(R.id.doctorName);
        specialization = findViewById(R.id.specialization);
        fee = findViewById(R.id.fee);
        patientName = findViewById(R.id.patientName);
        patientPhone = findViewById(R.id.patientPhone);
        confirmBtn = findViewById(R.id.confirmBtn);
        backBtn = findViewById(R.id.backBtn);
        selectDateBtn = findViewById(R.id.selectDateBtn);
        selectedDateText = findViewById(R.id.selectedDateText);
        selectedTimeText = findViewById(R.id.selectedTimeText);
        timeSlotsLayout = findViewById(R.id.timeSlotsLayout);

        db = new DBHelper(this);
        calendar = Calendar.getInstance();

        // Get doctor details from intent
        currentDoctorName = getIntent().getStringExtra("doctorName");
        String dSpec = getIntent().getStringExtra("specialization");
        String dFee = getIntent().getStringExtra("fee");

        // Set doctor details
        doctorName.setText(currentDoctorName);
        specialization.setText(dSpec);
        fee.setText("Fee: ₹" + dFee);

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Date picker button click
        selectDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        // Confirm booking button click
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookAppointment(currentDoctorName, dSpec, dFee);
            }
        });
    }

    private void showDatePicker() {
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    calendar.set(selectedYear, selectedMonth, selectedDay);

                    // Format date as YYYY-MM-DD
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    selectedDate = dateFormat.format(calendar.getTime());

                    // Display selected date
                    SimpleDateFormat displayFormat = new SimpleDateFormat("EEE, MMM dd, yyyy", Locale.getDefault());
                    selectedDateText.setText("Selected: " + displayFormat.format(calendar.getTime()));

                    // Generate time slots for selected date
                    generateTimeSlots();
                },
                year, month, day
        );

        // Set minimum date to today
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);

        // Set maximum date to 3 months from now
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.MONTH, 3);
        datePickerDialog.getDatePicker().setMaxDate(maxDate.getTimeInMillis());

        datePickerDialog.show();
    }

    private void generateTimeSlots() {
        // Clear previous time slots
        timeSlotsLayout.removeAllViews();
        timeSlotButtons.clear();
        selectedTime = "";
        selectedTimeText.setText("Selected Time: None");

        // Get booked time slots for this doctor and date
        ArrayList<String> bookedSlots = db.getBookedTimeSlots(currentDoctorName, selectedDate);

        // Generate time slots from 9:00 AM to 6:00 PM in 15-minute intervals
        int startHour = 9; // 9 AM
        int endHour = 18;  // 6 PM

        // Create rows for better organization (optional)
        LinearLayout currentRow = createNewRow();

        for (int hour = startHour; hour < endHour; hour++) {
            for (int minute = 0; minute < 60; minute += 15) {
                String timeSlot = formatTime(hour, minute);
                boolean isBooked = bookedSlots.contains(timeSlot);

                Button timeButton = createTimeSlotButton(timeSlot, isBooked);
                currentRow.addView(timeButton);

                // Add to buttons list for selection management
                timeSlotButtons.add(timeButton);
            }
        }

        // Add the last row if it has buttons
        if (currentRow.getChildCount() > 0) {
            timeSlotsLayout.addView(currentRow);
        }
    }

    private LinearLayout createNewRow() {
        LinearLayout row = new LinearLayout(this);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private Button createTimeSlotButton(String timeSlot, boolean isBooked) {
        Button timeButton = new Button(this);
        timeButton.setText(timeSlot);
        timeButton.setTag(timeSlot);

        // Set button styling
        if (isBooked) {
            timeButton.setBackgroundResource(R.drawable.btn_bg);
            timeButton.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
            timeButton.setTextColor(getResources().getColor(android.R.color.white));
            timeButton.setEnabled(false);
        } else {
            timeButton.setBackgroundResource(R.drawable.btn_bg);
            timeButton.setBackgroundTintList(getResources().getColorStateList(R.color.colorPrimary));
            timeButton.setTextColor(getResources().getColor(android.R.color.white));
            timeButton.setEnabled(true);
        }

        timeButton.setPadding(16, 8, 16, 8);
        timeButton.setTextSize(12);

        // Set layout parameters
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(8, 8, 8, 8);
        timeButton.setLayoutParams(params);

        // Add click listener
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectTimeSlot(timeSlot, timeButton);
            }
        });

        return timeButton;
    }

    private String formatTime(int hour, int minute) {
        String period = "AM";
        int displayHour = hour;

        if (hour >= 12) {
            period = "PM";
            if (hour > 12) {
                displayHour = hour - 12;
            }
        }
        if (hour == 0) {
            displayHour = 12;
        }

        return String.format(Locale.getDefault(), "%02d:%02d %s", displayHour, minute, period);
    }


    private void selectTimeSlot(String timeSlot, Button selectedButton) {
        // Reset all buttons to default state
        for (Button button : timeSlotButtons) {
            if (button.isEnabled()) {
                button.setBackgroundTintList(getResources().getColorStateList(R.color.colorPrimary));
            }
        }

        // Highlight selected button
        selectedButton.setBackgroundTintList(getResources().getColorStateList(R.color.colorAccent));
        selectedTime = timeSlot;
        selectedTimeText.setText("Selected Time: " + timeSlot);
    }

    private void bookAppointment(String doctorName, String specialization, String fee) {
        try {
            String pName = patientName.getText().toString().trim();
            String pPhone = patientPhone != null ? patientPhone.getText().toString().trim() : "";

            Log.d("DoctorBooking", "Patient: " + pName + ", Date: " + selectedDate + ", Time: " + selectedTime);

            // Validation
            if (pName.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields and select date/time", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isValidName(pName)) {
                patientName.setError("Please enter a valid name (2-30 characters, letters only)");
                return;
            }

            if (patientPhone != null && !pPhone.isEmpty() && !isValidPhone(pPhone)) {
                patientPhone.setError("Please enter a valid 10-digit phone number");
                return;
            }

            // Double-check if time slot is still available
            if (db.isTimeSlotBooked(doctorName, selectedDate, selectedTime)) {
                Toast.makeText(this, "This time slot has been booked by someone else. Please choose another slot.", Toast.LENGTH_LONG).show();
                generateTimeSlots(); // Refresh time slots
                return;
            }

            // Get current user ID from session
            SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
            int currentUserId = sharedPreferences.getInt("user_id", -1);

            Log.d("DoctorBooking", "User ID: " + currentUserId);

            if (currentUserId == -1) {
                Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
                return;
            }

            // Insert appointment into database with user ID
            boolean inserted = db.insertAppointment(pName, doctorName, specialization, fee, selectedDate, selectedTime, currentUserId);
            Log.d("DoctorBooking", "Appointment insertion result: " + inserted);

            if (inserted) {
                Toast.makeText(this, "Appointment booked successfully!", Toast.LENGTH_LONG).show();
                finish(); // return to previous screen
            } else {
                Toast.makeText(this, "Failed to book appointment", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("DoctorBooking", "Error booking appointment: " + e.getMessage(), e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // Validation methods
    private boolean isValidName(String name) {
        return name != null && NAME_PATTERN.matcher(name).matches();
    }

    private boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone).matches();
    }
}