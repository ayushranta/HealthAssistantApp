package com.example.healthasistence.labtests;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<LabTestModel> cartList;
    CartAdapter adapter;
    DBHelper db;
    Button checkoutBtn, backToTestsBtn;
    TextView totalPrice, cartTitle, cartSubtitle;
    ImageView backBtn;
    LinearLayout emptyCartLayout, cartItemsLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // Initialize views
        recyclerView = findViewById(R.id.cartRecycler);
        checkoutBtn = findViewById(R.id.checkoutBtn);
        backToTestsBtn = findViewById(R.id.backToTestsBtn);
        totalPrice = findViewById(R.id.totalPrice);
        backBtn = findViewById(R.id.backBtn);
        emptyCartLayout = findViewById(R.id.emptyCartLayout);
        cartItemsLayout = findViewById(R.id.cartItemsLayout);
        cartTitle = findViewById(R.id.cartTitle);
        cartSubtitle = findViewById(R.id.cartSubtitle);

        db = new DBHelper(this);
        cartList = new ArrayList<>();

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load cart items
        loadCartItems();

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Back to Tests button click
        backToTestsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Checkout button click - SIMPLE FIX
        checkoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cartList.isEmpty()) {
                    Toast.makeText(CartActivity.this, "Cart is Empty", Toast.LENGTH_SHORT).show();
                } else {
                    // Simple solution: Go to PatientDetailsActivity (your original flow)
                    startActivity(new Intent(CartActivity.this, PatientDetailsActivity.class));
                }
            }
        });
    }

    private void loadCartItems() {
        cartList.clear();

        // Get current user ID from session
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        int currentUserId = sharedPreferences.getInt("user_id", -1);

        if (currentUserId == -1) {
            showEmptyCart();
            return;
        }

        Cursor c = db.getCartItems(currentUserId);
        int total = 0;

        if (c != null && c.moveToFirst()) {
            do {
                String name = c.getString(c.getColumnIndexOrThrow("testName"));
                String desc = c.getString(c.getColumnIndexOrThrow("description"));
                String price = c.getString(c.getColumnIndexOrThrow("price"));
                total += Integer.parseInt(price);
                cartList.add(new LabTestModel(name, desc, price, R.drawable.health1));
            } while (c.moveToNext());
            c.close();
        }

        // Update UI based on cart state
        if (cartList.isEmpty()) {
            showEmptyCart();
        } else {
            showCartItems(total);
        }
    }

    private void showEmptyCart() {
        emptyCartLayout.setVisibility(View.VISIBLE);
        cartItemsLayout.setVisibility(View.GONE);
        cartTitle.setText("My Cart");
        cartSubtitle.setText("Your cart is empty");
    }

    private void showCartItems(int total) {
        emptyCartLayout.setVisibility(View.GONE);
        cartItemsLayout.setVisibility(View.VISIBLE);
        cartTitle.setText("My Cart (" + cartList.size() + " items)");
        cartSubtitle.setText("Review your selected tests");

        totalPrice.setText("₹" + total);

        adapter = new CartAdapter(this, cartList);
        recyclerView.setAdapter(adapter);
    }

    public void onBrowseTestsClick(View view) {
        finish(); // Go back to Lab Tests
    }

    public void refreshCart() {
        loadCartItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCartItems();
    }
}