package com.example.healthasistence.doctors;

public class DoctorModel {
    String name, specialization, experience, fee;
    int image;

    public DoctorModel(String name, String specialization, String experience, String fee, int image) {
        this.name = name;
        this.specialization = specialization;
        this.experience = experience;
        this.fee = fee;
        this.image = image;
    }

    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public String getExperience() { return experience; }
    public String getFee() { return fee; }
    public int getImage() { return image; }
}