package com.example.healthasistence.articles;

public class ArticleModel {
    String title;
    String image;

    public ArticleModel(String title, String image) {
        this.title = title;
        this.image = image;
    }

    public String getTitle() { return title; }
    public String getImage() { return image; }
}