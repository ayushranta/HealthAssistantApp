package com.example.healthasistence.articles;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;

import java.util.ArrayList;

public class ArticleAdapter extends RecyclerView.Adapter<ArticleAdapter.ViewHolder> {

    Context context;
    ArrayList<ArticleModel> list;

    public ArticleAdapter(Context context, ArrayList<ArticleModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_article, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ArticleModel model = list.get(position);
        holder.title.setText(model.getTitle());

        // Set image based on article image name
        String imageName = model.getImage();
        int imageResource = getImageResource(imageName);
        holder.image.setImageResource(imageResource);

        // Item click listener
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, ArticleDetailActivity.class);
                i.putExtra("title", model.getTitle());
                i.putExtra("image", model.getImage());
                context.startActivity(i);
            }
        });
    }

    private int getImageResource(String imageName) {
        switch (imageName) {
            case "benefits":
                return R.drawable.benefits;
            case "healthy":
                return R.drawable.healthy;
            case "managing":
                return R.drawable.managing;
            case "importance":
                return R.drawable.importance;
            case "hearthealth":
                return R.drawable.hearthealth;
            case "mental":
                return R.drawable.mental; // Can reuse or add more images
            case "daily":
                return R.drawable.daily; // Can reuse or add more images
            case "nutrition":
                return R.drawable.nutrition; // Can reuse or add more images
            default:
                return R.drawable.health1;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.articleTitle);
            image = itemView.findViewById(R.id.articleImage);
        }
    }
}