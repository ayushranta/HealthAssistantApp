package com.example.healthasistence.doctors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;

import java.util.ArrayList;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.ViewHolder> {

    Context context;
    ArrayList<DoctorModel> list;

    public DoctorAdapter(Context context, ArrayList<DoctorModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_doctor, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DoctorModel model = list.get(position);

        holder.name.setText(model.getName());
        holder.specialization.setText(model.getSpecialization());
        holder.experience.setText(model.getExperience());
        holder.fee.setText("Fee: ₹" + model.getFee());
        holder.image.setImageResource(model.getImage());

        // View Details button click
        holder.detailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, DoctorDetailActivity.class);
                i.putExtra("name", model.getName());
                i.putExtra("specialization", model.getSpecialization());
                i.putExtra("experience", model.getExperience());
                i.putExtra("fee", model.getFee());
                i.putExtra("image", model.getImage());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, specialization, experience, fee;
        ImageView image;
        Button detailBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.doctorName);
            specialization = itemView.findViewById(R.id.doctorSpecialization);
            experience = itemView.findViewById(R.id.doctorExperience);
            fee = itemView.findViewById(R.id.doctorFee);
            image = itemView.findViewById(R.id.doctorImage);
            detailBtn = itemView.findViewById(R.id.detailBtn);
        }
    }
}