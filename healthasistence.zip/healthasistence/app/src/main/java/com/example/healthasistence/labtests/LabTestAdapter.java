package com.example.healthasistence.labtests;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;

import java.util.ArrayList;

public class LabTestAdapter extends RecyclerView.Adapter<LabTestAdapter.ViewHolder> {

    Context context;
    ArrayList<LabTestModel> list;

    public LabTestAdapter(Context context, ArrayList<LabTestModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_labtest, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LabTestModel model = list.get(position);

        holder.name.setText(model.getName());
        holder.description.setText(model.getDescription());
        holder.price.setText("₹" + model.getPrice());
        holder.image.setImageResource(model.getImage());

        // Detail button click
        holder.detailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, LabTestDetailActivity.class);
                i.putExtra("name", model.getName());
                i.putExtra("desc", model.getDescription());
                i.putExtra("price", model.getPrice());
                i.putExtra("image", model.getImage());
                context.startActivity(i);
            }
        });

        // Whole item click
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, LabTestDetailActivity.class);
                i.putExtra("name", model.getName());
                i.putExtra("desc", model.getDescription());
                i.putExtra("price", model.getPrice());
                i.putExtra("image", model.getImage());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, description, price;
        ImageView image;
        Button detailBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.labTestName);
            description = itemView.findViewById(R.id.labTestDescription);
            price = itemView.findViewById(R.id.labTestPrice);
            image = itemView.findViewById(R.id.labTestImage);
            detailBtn = itemView.findViewById(R.id.detailBtn);
        }
    }
}