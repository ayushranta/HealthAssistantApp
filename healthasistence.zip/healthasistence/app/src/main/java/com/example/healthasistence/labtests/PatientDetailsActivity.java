package com.example.healthasistence.labtests;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;
import com.example.healthasistence.orders.OrdersActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class PatientDetailsActivity extends AppCompatActivity {
    EditText patientName, patientAge, patientPhone, patientDate;
    TextView selectedTimeText;
    RadioGroup genderRadioGroup;
    RadioButton maleRadio, femaleRadio, otherRadio;
    Button confirmBtn, backToCartBtn, selectDateBtn;
    ImageView backBtn;
    DBHelper db;
    ArrayList<LabTestModel> cartItems;

    private Calendar calendar;
    private String selectedTime = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details);

        // Initialize views
        patientName = findViewById(R.id.patientName);
        patientAge = findViewById(R.id.patientAge);
        patientPhone = findViewById(R.id.patientPhone);
        patientDate = findViewById(R.id.patientDate);
        selectedTimeText = findViewById(R.id.selectedTimeText);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        maleRadio = findViewById(R.id.maleRadio);
        femaleRadio = findViewById(R.id.femaleRadio);
        otherRadio = findViewById(R.id.otherRadio);
        confirmBtn = findViewById(R.id.confirmBtn);
        backBtn = findViewById(R.id.backBtn);
        backToCartBtn = findViewById(R.id.backToCartBtn);
        selectDateBtn = findViewById(R.id.selectDateBtn);

        db = new DBHelper(this);
        cartItems = new ArrayList<>();
        calendar = Calendar.getInstance();

        // Load cart items
        loadCartItems();

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Back to Cart button click
        backToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Date picker button click
        selectDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        // Time slot buttons
        setupTimeSlots();

        // Confirm order button click
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeOrder();
            }
        });
    }

    private void showDatePicker() {
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    calendar.set(selectedYear, selectedMonth, selectedDay);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    patientDate.setText(dateFormat.format(calendar.getTime()));
                },
                year, month, day
        );

        // Set minimum date to today
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private void setupTimeSlots() {
        // Simple time slot buttons
        int[] timeButtons = {R.id.time9am, R.id.time10am, R.id.time11am, R.id.time12pm,
                R.id.time2pm, R.id.time3pm, R.id.time4pm, R.id.time5pm};

        String[] times = {"09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
                "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"};

        for (int i = 0; i < timeButtons.length; i++) {
            Button timeBtn = findViewById(timeButtons[i]);
            final String time = times[i];

            timeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedTime = time;
                    selectedTimeText.setText("Selected Time: " + time);

                    // Reset all buttons to default
                    for (int j = 0; j < timeButtons.length; j++) {
                        Button btn = findViewById(timeButtons[j]);
                        btn.setBackgroundResource(R.drawable.btn_bg);
                        btn.setBackgroundTintList(getResources().getColorStateList(R.color.colorPrimary));
                        btn.setTextColor(getResources().getColor(android.R.color.white));
                    }

                    // Highlight selected button
                    timeBtn.setBackgroundTintList(getResources().getColorStateList(R.color.colorAccent));
                }
            });
        }
    }

    private void loadCartItems() {
        // Get current user ID from session
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        int currentUserId = sharedPreferences.getInt("user_id", -1);

        if (currentUserId == -1) return;

        Cursor c = db.getCartItems(currentUserId);
        if (c != null && c.moveToFirst()) {
            do {
                String name = c.getString(c.getColumnIndexOrThrow("testName"));
                String desc = c.getString(c.getColumnIndexOrThrow("description"));
                String price = c.getString(c.getColumnIndexOrThrow("price"));
                cartItems.add(new LabTestModel(name, desc, price, R.drawable.health1));
            } while (c.moveToNext());
            c.close();
        }
    }

    private void placeOrder() {
        String pname = patientName.getText().toString().trim();
        String page = patientAge.getText().toString().trim();
        String pphone = patientPhone.getText().toString().trim();
        String pdate = patientDate.getText().toString().trim();
        String pgender = getSelectedGender();

        // Simple validation
        if (pname.isEmpty() || page.isEmpty() || pphone.isEmpty() || pdate.isEmpty() || selectedTime.isEmpty() || pgender.isEmpty()) {
            Toast.makeText(this, "Please fill all fields and select time", Toast.LENGTH_SHORT).show();
            return;
        }

        // Phone validation (simple)
        if (!isValidPhone(pphone)) {
            patientPhone.setError("Enter valid 10-digit phone number");
            return;
        }

        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Cart is Empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get current user ID from session
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        int currentUserId = sharedPreferences.getInt("user_id", -1);

        if (currentUserId == -1) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            return;
        }

        // Place order with user ID, date, and time
        boolean success = db.placeLabTestOrderWithDateTime(cartItems, pname, page, pgender, pdate, selectedTime, currentUserId);
        if (success) {
            // Clear cart for this user
            db.clearCart(currentUserId);
            Toast.makeText(this, "Order placed successfully", Toast.LENGTH_SHORT).show();

            // Go to Orders page
            Intent intent = new Intent(PatientDetailsActivity.this, OrdersActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Failed to place Order", Toast.LENGTH_SHORT).show();
        }
    }

    // Get selected gender from radio buttons
    private String getSelectedGender() {
        int selectedId = genderRadioGroup.getCheckedRadioButtonId();

        if (selectedId == R.id.maleRadio) {
            return "Male";
        } else if (selectedId == R.id.femaleRadio) {
            return "Female";
        } else if (selectedId == R.id.otherRadio) {
            return "Other";
        } else {
            return ""; // No gender selected
        }
    }

    // Simple phone validation
    private boolean isValidPhone(String phone) {
        return phone.matches("^[6-9]\\d{9}$");
    }
}