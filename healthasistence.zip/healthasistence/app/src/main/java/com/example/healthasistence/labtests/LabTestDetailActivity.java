package com.example.healthasistence.labtests;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;

public class LabTestDetailActivity extends AppCompatActivity {
    TextView detailName, detailDescription, detailPrice, testIncludes, testPreparation;
    ImageView detailImage, backBtn;
    Button addToCartBtn;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_test_detail);

        // Initialize views
        detailName = findViewById(R.id.detailLabTestName);
        detailDescription = findViewById(R.id.detailLabTestDescription);
        detailPrice = findViewById(R.id.detailLabTestPrice);
        detailImage = findViewById(R.id.detailLabTestImage);
        backBtn = findViewById(R.id.backBtn);
        addToCartBtn = findViewById(R.id.addToCartBtn);
        testIncludes = findViewById(R.id.testIncludes);
        testPreparation = findViewById(R.id.testPreparation);
        db = new DBHelper(this);

        // Get test data from intent
        String tName = getIntent().getStringExtra("name");
        String tDesc = getIntent().getStringExtra("desc");
        String tPrice = getIntent().getStringExtra("price");
        int tImage = getIntent().getIntExtra("image", R.drawable.health1);

        // Set values
        detailName.setText(tName);
        detailDescription.setText(tDesc);
        detailPrice.setText("₹" + tPrice);
        detailImage.setImageResource(tImage);

        // Set dynamic content based on test name
        setTestDetails(tName);

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Add to Cart button click
        addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get current user ID from session
                SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
                int currentUserId = sharedPreferences.getInt("user_id", -1);

                if (currentUserId == -1) {
                    Toast.makeText(LabTestDetailActivity.this, "Please login first", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean inserted = db.addToCart(tName, tDesc, tPrice, currentUserId);
                if (inserted) {
                    Toast.makeText(LabTestDetailActivity.this, "Added to Cart", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LabTestDetailActivity.this, "Already in Cart", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setTestDetails(String testName) {
        String includes = "";
        String preparation = "";

        if (testName.equals("Full Body Checkup")) {
            includes = "- Complete Blood Count (CBC)\n- Liver Function Tests\n- Kidney Function Tests\n- Thyroid Profile (T3, T4, TSH)\n- Lipid Profile\n- Blood Sugar Tests\n- Urine Routine Analysis\n- Vitamin D and B12 Levels";
            preparation = "- 10-12 hours fasting required\n- Avoid alcohol for 24 hours\n- Inform about current medications\n- No strenuous exercise before test";
        } else if (testName.equals("Blood Test")) {
            includes = "- Complete Blood Count (CBC)\n- Hemoglobin Levels\n- Blood Sugar (Fasting)\n- Cholesterol Levels\n- Platelet Count";
            preparation = "- 8-10 hours fasting required\n- Can drink water\n- No special preparation needed";
        } else if (testName.equals("Diabetes Test")) {
            includes = "- Fasting Blood Sugar\n- Post Prandial Blood Sugar\n- HbA1c Test\n- Glucose Tolerance Test";
            preparation = "- 10-12 hours fasting required\n- Avoid diabetes medications before test\n- Follow doctor's instructions";
        } else if (testName.equals("Thyroid Profile")) {
            includes = "- TSH (Thyroid Stimulating Hormone)\n- T3 (Triiodothyronine)\n- T4 (Thyroxine)\n- Free T3 and T4";
            preparation = "- No fasting required\n- Can take medications as usual\n- No special preparation";
        } else if (testName.equals("Liver Function Test")) {
            includes = "- SGOT (AST)\n- SGPT (ALT)\n- Bilirubin (Total & Direct)\n- Albumin\n- Total Protein\n- Alkaline Phosphatase";
            preparation = "- 8-10 hours fasting required\n- Avoid alcohol for 48 hours\n- No heavy meals before test";
        } else if (testName.equals("Kidney Function Test")) {
            includes = "- Serum Creatinine\n- Blood Urea Nitrogen (BUN)\n- Uric Acid\n- Electrolytes (Sodium, Potassium)\n- Estimated GFR";
            preparation = "- No fasting required\n- Stay well hydrated\n- Avoid strenuous exercise";
        } else if (testName.equals("Cardiac Risk Markers")) {
            includes = "- Lipid Profile\n- CRP (C-Reactive Protein)\n- Homocysteine\n- Apolipoprotein\n- Cardiac Enzymes";
            preparation = "- 12-14 hours fasting required\n- Avoid fatty foods for 24 hours\n- No alcohol for 48 hours";
        } else if (testName.equals("Vitamin Panel")) {
            includes = "- Vitamin D (25-OH)\n- Vitamin B12\n- Folate\n- Iron Studies\n- Ferritin Levels";
            preparation = "- No fasting required\n- Can take normal diet\n- No special preparation needed";
        } else {
            includes = "- Basic blood tests\n- Routine health parameters\n- Standard diagnostic tests";
            preparation = "- Follow general instructions\n- Consult with healthcare provider\n- No special preparation";
        }

        testIncludes.setText(includes);
        testPreparation.setText(preparation);
    }
}