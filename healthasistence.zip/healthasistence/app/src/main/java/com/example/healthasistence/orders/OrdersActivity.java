package com.example.healthasistence.orders;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;
import com.example.healthasistence.main.MainMenuActivity;

import java.util.ArrayList;

public class OrdersActivity extends AppCompatActivity {
    RecyclerView appointmentsRecycler, labTestsRecycler;
    ArrayList<OrderModel> appointmentList, labTestList;
    OrderAdapter appointmentsAdapter, labTestsAdapter;
    DBHelper db;
    ImageView backBtn;
    Button backToMainBtn;
    LinearLayout emptyOrdersLayout, ordersContentLayout;
    int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        // Initialize views
        appointmentsRecycler = findViewById(R.id.appointmentsRecycler);
        labTestsRecycler = findViewById(R.id.labTestsRecycler);
        backBtn = findViewById(R.id.backBtn);
        backToMainBtn = findViewById(R.id.backToMainBtn);
        emptyOrdersLayout = findViewById(R.id.emptyOrdersLayout);
        ordersContentLayout = findViewById(R.id.ordersContentLayout);

        db = new DBHelper(this);

        // Get current user ID from session
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        currentUserId = sharedPreferences.getInt("user_id", -1);

        // Setup RecyclerViews
        appointmentsRecycler.setLayoutManager(new LinearLayoutManager(this));
        labTestsRecycler.setLayoutManager(new LinearLayoutManager(this));

        // Back button click - Go to Main Menu instead of back navigation
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMainMenu();
            }
        });

        // Back to Main Menu button click
        backToMainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMainMenu();
            }
        });

        // Load orders
        loadOrders();
    }

    private void goToMainMenu() {
        // Clear the back stack and go to Main Menu
        Intent intent = new Intent(OrdersActivity.this, MainMenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    // Override the hardware back button too
    @Override
    public void onBackPressed() {
        goToMainMenu();
    }

    public void loadOrders() {
        appointmentList = new ArrayList<>();
        labTestList = new ArrayList<>();

        // Load appointments for current user
        loadAppointments();

        // Load lab orders for current user
        loadLabOrders();

        // Update UI based on orders
        updateUI();
    }

    private void loadAppointments() {
        if (currentUserId == -1) return;

        Cursor c = db.getAppointments(currentUserId);
        if (c != null && c.moveToFirst()) {
            do {
                String patient = c.getString(c.getColumnIndexOrThrow("patientName"));
                String doctor = c.getString(c.getColumnIndexOrThrow("doctorName"));
                String spec = c.getString(c.getColumnIndexOrThrow("specialization"));
                String fee = c.getString(c.getColumnIndexOrThrow("fee"));
                String date = c.getString(c.getColumnIndexOrThrow("date"));
                String time = c.getString(c.getColumnIndexOrThrow("time"));
                appointmentList.add(new OrderModel("APPOINTMENT", patient, doctor, spec, fee, date, time));
            } while (c.moveToNext());
            c.close();
        }
    }

    private void loadLabOrders() {
        if (currentUserId == -1) return;

        Cursor c = db.getLabOrders(currentUserId);
        if (c != null && c.moveToFirst()) {
            do {
                String patient = c.getString(c.getColumnIndexOrThrow("patientName"));
                String testName = c.getString(c.getColumnIndexOrThrow("testName"));
                String price = c.getString(c.getColumnIndexOrThrow("price"));
                String age = c.getString(c.getColumnIndexOrThrow("age"));
                String gender = c.getString(c.getColumnIndexOrThrow("gender"));
                String date = c.getString(c.getColumnIndexOrThrow("appointmentDate"));
                String time = c.getString(c.getColumnIndexOrThrow("appointmentTime"));

                // Use date and time if available, otherwise use default values
                String displayDate = (date != null && !date.isEmpty()) ? date : "Not scheduled";
                String displayTime = (time != null && !time.isEmpty()) ? time : "";

                labTestList.add(new OrderModel("LAB_TEST", patient, testName, "Lab Test", "₹" + price, displayDate, displayTime));
            } while (c.moveToNext());
            c.close();
        }
    }

    public void updateUI() {
        boolean hasAppointments = !appointmentList.isEmpty();
        boolean hasLabTests = !labTestList.isEmpty();

        if (!hasAppointments && !hasLabTests) {
            // Show empty state
            emptyOrdersLayout.setVisibility(View.VISIBLE);
            ordersContentLayout.setVisibility(View.GONE);
        } else {
            // Show orders content
            emptyOrdersLayout.setVisibility(View.GONE);
            ordersContentLayout.setVisibility(View.VISIBLE);

            // Setup appointments recycler
            if (hasAppointments) {
                appointmentsAdapter = new OrderAdapter(this, appointmentList, "APPOINTMENT", db, currentUserId);
                appointmentsRecycler.setAdapter(appointmentsAdapter);
                appointmentsRecycler.setVisibility(View.VISIBLE);
            } else {
                appointmentsRecycler.setVisibility(View.GONE);
            }

            // Setup lab tests recycler
            if (hasLabTests) {
                labTestsAdapter = new OrderAdapter(this, labTestList, "LAB_TEST", db, currentUserId);
                labTestsRecycler.setAdapter(labTestsAdapter);
                labTestsRecycler.setVisibility(View.VISIBLE);
            } else {
                labTestsRecycler.setVisibility(View.GONE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadOrders();
    }
}