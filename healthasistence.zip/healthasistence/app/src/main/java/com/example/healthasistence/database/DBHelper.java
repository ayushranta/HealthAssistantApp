package com.example.healthasistence.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.healthasistence.labtests.LabTestModel;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "Healthcare.db", null, 5); // Increased version to 5
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("CREATE TABLE users(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "email TEXT UNIQUE," +
                "password TEXT)");

        // Create cart table with user ID
        db.execSQL("CREATE TABLE cart(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "userId INTEGER," +
                "testName TEXT," +
                "description TEXT," +
                "price TEXT," +
                "FOREIGN KEY(userId) REFERENCES users(id))");

        // Create appointments table with user ID
        db.execSQL("CREATE TABLE appointments(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "userId INTEGER," +
                "patientName TEXT," +
                "doctorName TEXT," +
                "specialization TEXT," +
                "fee TEXT," +
                "date TEXT," +
                "time TEXT," +
                "FOREIGN KEY(userId) REFERENCES users(id))");

        // Create lab_orders table with user ID - updated to include date and time
        db.execSQL("CREATE TABLE lab_orders(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "userId INTEGER," +
                "patientName TEXT," +
                "age TEXT," +
                "gender TEXT," +
                "testName TEXT," +
                "price TEXT," +
                "appointmentDate TEXT," +  // Add this
                "appointmentTime TEXT," +  // Add this
                "FOREIGN KEY(userId) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 5) {
            // Drop old tables and recreate with new schema
            db.execSQL("DROP TABLE IF EXISTS users");
            db.execSQL("DROP TABLE IF EXISTS cart");
            db.execSQL("DROP TABLE IF EXISTS appointments");
            db.execSQL("DROP TABLE IF EXISTS lab_orders");
            onCreate(db);
        }
    }

    // Insert new user and return user ID
    public long insertUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("email", email);
        cv.put("password", password);
        long result = db.insert("users", null, cv);
        return result; // Returns the new user ID
    }

    // Check if user exists for login and return user ID
    public int checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM users WHERE email=? AND password=?",
                new String[]{email, password});

        int userId = -1;
        if (c.moveToFirst()) {
            userId = c.getInt(c.getColumnIndexOrThrow("id"));
        }
        c.close();
        return userId; // Returns user ID if found, -1 if not
    }

    // Get user by email (for session management)
    public int getUserIdByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM users WHERE email=?", new String[]{email});

        int userId = -1;
        if (c.moveToFirst()) {
            userId = c.getInt(c.getColumnIndexOrThrow("id"));
        }
        c.close();
        return userId;
    }

    // Add to cart with user ID
    public boolean addToCart(String testName, String description, String price, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if item already exists in cart for this user
        Cursor cursor = db.rawQuery("SELECT * FROM cart WHERE testName=? AND userId=?",
                new String[]{testName, String.valueOf(userId)});

        if (cursor.getCount() > 0) {
            cursor.close();
            return false; // Item already in cart for this user
        }
        cursor.close();

        ContentValues cv = new ContentValues();
        cv.put("testName", testName);
        cv.put("description", description);
        cv.put("price", price);
        cv.put("userId", userId);
        long result = db.insert("cart", null, cv);
        return result != -1;
    }

    // Get cart items for specific user
    public Cursor getCartItems(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM cart WHERE userId=?", new String[]{String.valueOf(userId)});
    }

    // Clear cart for specific user
    public void clearCart(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM cart WHERE userId=?", new String[]{String.valueOf(userId)});
    }

    // Remove from cart for specific user
    public boolean removeFromCart(String testName, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("cart", "testName=? AND userId=?",
                new String[]{testName, String.valueOf(userId)});
        return result > 0;
    }

    // Insert appointment with user ID
    public boolean insertAppointment(String patientName, String doctorName,
                                     String specialization, String fee,
                                     String date, String time, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("patientName", patientName);
        cv.put("doctorName", doctorName);
        cv.put("specialization", specialization);
        cv.put("fee", fee);
        cv.put("date", date);
        cv.put("time", time);
        cv.put("userId", userId);
        long result = db.insert("appointments", null, cv);
        Log.d("DB_DEBUG", "Insert appointment result: " + result);
        return result != -1;
    }

    // Place lab test order with date and time
    public boolean placeLabTestOrderWithDateTime(ArrayList<LabTestModel> cartItems,
                                                 String patientName, String age,
                                                 String gender, String date, String time,
                                                 int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean allSuccess = true;

        for (LabTestModel item : cartItems) {
            ContentValues cv = new ContentValues();
            cv.put("patientName", patientName);
            cv.put("age", age);
            cv.put("gender", gender);
            cv.put("testName", item.getName());
            cv.put("price", item.getPrice());
            cv.put("appointmentDate", date);
            cv.put("appointmentTime", time);
            cv.put("userId", userId);
            long result = db.insert("lab_orders", null, cv);
            Log.d("DB_DEBUG", "Insert lab order result: " + result + " for test: " + item.getName());

            if (result == -1) {
                allSuccess = false;
            }
        }
        return allSuccess;
    }

    // Get appointments for specific user
    public Cursor getAppointments(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM appointments WHERE userId=?",
                new String[]{String.valueOf(userId)});
    }

    // Check if a time slot is already booked for a doctor and date
    public boolean isTimeSlotBooked(String doctorName, String date, String time) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM appointments WHERE doctorName = ? AND date = ? AND time = ?",
                new String[]{doctorName, date, time}
        );
        boolean isBooked = cursor.getCount() > 0;
        cursor.close();
        return isBooked;
    }

    // Get all booked time slots for a doctor on a specific date
    public ArrayList<String> getBookedTimeSlots(String doctorName, String date) {
        ArrayList<String> bookedSlots = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT time FROM appointments WHERE doctorName = ? AND date = ?",
                new String[]{doctorName, date}
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                bookedSlots.add(cursor.getString(cursor.getColumnIndexOrThrow("time")));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return bookedSlots;
    }

    // Remove appointment for specific user
    public boolean removeAppointment(String patientName, String doctorName,
                                     String date, String time, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("appointments",
                "patientName=? AND doctorName=? AND date=? AND time=? AND userId=?",
                new String[]{patientName, doctorName, date, time, String.valueOf(userId)});
        Log.d("DB_DEBUG", "Remove appointment result: " + result);
        return result > 0;
    }

    // Place lab test order with user ID (without date/time - for backward compatibility)
    public boolean placeLabTestOrder(ArrayList<LabTestModel> cartItems,
                                     String patientName, String age,
                                     String gender, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean allSuccess = true;

        for (LabTestModel item : cartItems) {
            ContentValues cv = new ContentValues();
            cv.put("patientName", patientName);
            cv.put("age", age);
            cv.put("gender", gender);
            cv.put("testName", item.getName());
            cv.put("price", item.getPrice());
            cv.put("userId", userId);
            long result = db.insert("lab_orders", null, cv);
            Log.d("DB_DEBUG", "Insert lab order result: " + result + " for test: " + item.getName());

            if (result == -1) {
                allSuccess = false;
            }
        }
        return allSuccess;
    }

    // Get lab orders for specific user
    public Cursor getLabOrders(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM lab_orders WHERE userId=?",
                new String[]{String.valueOf(userId)});
    }

    // Remove lab order for specific user
    public boolean removeLabOrder(String patientName, String testName, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("lab_orders",
                "patientName=? AND testName=? AND userId=?",
                new String[]{patientName, testName, String.valueOf(userId)});
        Log.d("DB_DEBUG", "Remove lab order result: " + result);
        return result > 0;
    }
}