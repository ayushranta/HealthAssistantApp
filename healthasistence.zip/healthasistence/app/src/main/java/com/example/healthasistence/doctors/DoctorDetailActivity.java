package com.example.healthasistence.doctors;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;

public class DoctorDetailActivity extends AppCompatActivity {

    TextView name, specialization, experience, fee;
    ImageView image, backBtn;
    Button bookBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_detail);

        // Initialize views
        name = findViewById(R.id.detailDoctorName);
        specialization = findViewById(R.id.detailDoctorSpecialization);
        experience = findViewById(R.id.detailDoctorExperience);
        fee = findViewById(R.id.detailDoctorFee);
        image = findViewById(R.id.detailDoctorImage);
        backBtn = findViewById(R.id.backBtn);
        bookBtn = findViewById(R.id.bookBtn);

        // Get data from intent
        String dName = getIntent().getStringExtra("name");
        String dSpec = getIntent().getStringExtra("specialization");
        String dExp = getIntent().getStringExtra("experience");
        String dFee = getIntent().getStringExtra("fee");
        int dImage = getIntent().getIntExtra("image", R.drawable.doctor1);

        // Set values
        name.setText(dName);
        specialization.setText(dSpec);
        experience.setText(dExp);
        fee.setText("Fee: ₹" + dFee);
        image.setImageResource(dImage);

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Book Appointment button click
        bookBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DoctorDetailActivity.this, DoctorBookingActivity.class);
                i.putExtra("doctorName", dName);
                i.putExtra("specialization", dSpec);
                i.putExtra("fee", dFee);
                startActivity(i);
            }
        });
    }
}