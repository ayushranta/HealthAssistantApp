package com.example.healthasistence.articles;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;

import java.util.ArrayList;

public class ArticlesActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<ArticleModel> articleList;
    ArticleAdapter adapter;
    ImageView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_articles);

        // Initialize views
        recyclerView = findViewById(R.id.articlesRecycler);
        backBtn = findViewById(R.id.backBtn);

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Populate sample articles with different images
        articleList = new ArrayList<>();
        articleList.add(new ArticleModel("Benefits of Regular Exercise", "benefits"));
        articleList.add(new ArticleModel("Healthy Eating Habits", "healthy"));
        articleList.add(new ArticleModel("Managing Stress Effectively", "managing"));
        articleList.add(new ArticleModel("Importance of Sleep", "importance"));
        articleList.add(new ArticleModel("Heart Health Tips", "hearthealth"));
        articleList.add(new ArticleModel("Mental Wellness Guide", "mental"));
        articleList.add(new ArticleModel("Daily Fitness Routine", "daily"));
        articleList.add(new ArticleModel("Nutrition for All Ages", "nutrition"));

        adapter = new ArticleAdapter(this, articleList);
        recyclerView.setAdapter(adapter);
    }
}