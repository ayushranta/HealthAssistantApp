package com.example.healthasistence.labtests;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;
import com.example.healthasistence.main.MainMenuActivity;
import com.example.healthasistence.orders.OrdersActivity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class LabTestBookingActivity extends AppCompatActivity {
    TextView testName, testDescription, testPrice, selectedDateText, selectedTimeText, cartSummaryText;
    EditText patientName, patientAge, patientPhone;
    RadioGroup genderRadioGroup;
    RadioButton maleRadio, femaleRadio, otherRadio;
    Button confirmBtn, selectDateBtn, backToMainBtn;
    ImageView backBtn;
    LinearLayout timeSlotsLayout, cartSummaryLayout;
    DBHelper db;

    private String selectedDate = "";
    private String selectedTime = "";
    private Calendar calendar;
    private List<Button> timeSlotButtons = new ArrayList<>();
    private ArrayList<LabTestModel> cartItems;

    // Validation patterns
    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z ]{2,30}$");
    private static final Pattern AGE_PATTERN = Pattern.compile("^(?:[1-9]|[1-9][0-9]|1[0-4][0-9]|150)$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^[6-9]\\d{9}$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_test_booking);

        // Initialize views
        testName = findViewById(R.id.testName);
        testDescription = findViewById(R.id.testDescription);
        testPrice = findViewById(R.id.testPrice);
        patientName = findViewById(R.id.patientName);
        patientAge = findViewById(R.id.patientAge);
        patientPhone = findViewById(R.id.patientPhone);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        maleRadio = findViewById(R.id.maleRadio);
        femaleRadio = findViewById(R.id.femaleRadio);
        otherRadio = findViewById(R.id.otherRadio);
        confirmBtn = findViewById(R.id.confirmBtn);
        backBtn = findViewById(R.id.backBtn);
        selectDateBtn = findViewById(R.id.selectDateBtn);
        selectedDateText = findViewById(R.id.selectedDateText);
        selectedTimeText = findViewById(R.id.selectedTimeText);
        timeSlotsLayout = findViewById(R.id.timeSlotsLayout);
        cartSummaryText = findViewById(R.id.cartSummaryText);
        cartSummaryLayout = findViewById(R.id.cartSummaryLayout);
        backToMainBtn = findViewById(R.id.backToMainBtn);

        db = new DBHelper(this);
        calendar = Calendar.getInstance();
        cartItems = new ArrayList<>();

        // Get cart items from intent
        ArrayList<LabTestModel> receivedCartItems = (ArrayList<LabTestModel>) getIntent().getSerializableExtra("cartItems");
        if (receivedCartItems != null && !receivedCartItems.isEmpty()) {
            cartItems.addAll(receivedCartItems);
            updateCartSummary();
        } else {
            // Single test booking (backward compatibility)
            String tName = getIntent().getStringExtra("testName");
            String tDesc = getIntent().getStringExtra("testDescription");
            String tPrice = getIntent().getStringExtra("testPrice");

            if (tName != null && tPrice != null) {
                cartItems.add(new LabTestModel(tName, tDesc != null ? tDesc : "", tPrice, R.drawable.health1));
                updateCartSummary();
            }
        }

        // Set test details (show first item or summary for multiple)
        if (!cartItems.isEmpty()) {
            if (cartItems.size() == 1) {
                LabTestModel firstItem = cartItems.get(0);
                testName.setText(firstItem.getName());
                testDescription.setText(firstItem.getDescription());
                testPrice.setText("Price: ₹" + firstItem.getPrice());
            } else {
                testName.setText("Multiple Tests (" + cartItems.size() + " items)");
                testDescription.setText("Booking for " + cartItems.size() + " lab tests");
                int totalPrice = 0;
                for (LabTestModel item : cartItems) {
                    totalPrice += Integer.parseInt(item.getPrice());
                }
                testPrice.setText("Total Price: ₹" + totalPrice);
            }
        }

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Back to Main Menu button
        backToMainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMainMenu();
            }
        });

        // Date picker button click
        selectDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        // Confirm booking button click
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeOrder();
            }
        });
    }

    private void updateCartSummary() {
        if (cartItems.size() > 1) {
            cartSummaryLayout.setVisibility(View.VISIBLE);
            StringBuilder summary = new StringBuilder();
            int total = 0;

            for (LabTestModel item : cartItems) {
                summary.append("• ").append(item.getName()).append(" - ₹").append(item.getPrice()).append("\n");
                total += Integer.parseInt(item.getPrice());
            }
            summary.append("\nTotal: ₹").append(total);
            cartSummaryText.setText(summary.toString());
        } else {
            cartSummaryLayout.setVisibility(View.GONE);
        }
    }

    private void showDatePicker() {
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    calendar.set(selectedYear, selectedMonth, selectedDay);

                    // Format date as YYYY-MM-DD
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    selectedDate = dateFormat.format(calendar.getTime());

                    // Display selected date
                    SimpleDateFormat displayFormat = new SimpleDateFormat("EEE, MMM dd, yyyy", Locale.getDefault());
                    selectedDateText.setText("Selected: " + displayFormat.format(calendar.getTime()));

                    // Generate time slots for selected date
                    generateTimeSlots();
                },
                year, month, day
        );

        // Set minimum date to today
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);

        // Set maximum date to 1 month from now
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.MONTH, 1);
        datePickerDialog.getDatePicker().setMaxDate(maxDate.getTimeInMillis());

        datePickerDialog.show();
    }

    private void generateTimeSlots() {
        // Clear previous time slots
        timeSlotsLayout.removeAllViews();
        timeSlotButtons.clear();
        selectedTime = "";
        selectedTimeText.setText("Selected Time: None");

        // Generate time slots from 8:00 AM to 5:00 PM in 30-minute intervals
        int startHour = 8; // 8 AM
        int endHour = 17;  // 5 PM

        for (int hour = startHour; hour < endHour; hour++) {
            for (int minute = 0; minute < 60; minute += 30) {
                String timeSlot = formatTime(hour, minute);
                createTimeSlotButton(timeSlot);
            }
        }
    }

    private String formatTime(int hour, int minute) {
        String period = "AM";
        int displayHour = hour;

        if (hour >= 12) {
            period = "PM";
            if (hour > 12) {
                displayHour = hour - 12;
            }
        }
        if (hour == 0) {
            displayHour = 12;
        }

        return String.format(Locale.getDefault(), "%02d:%02d %s", displayHour, minute, period);
    }

    private void createTimeSlotButton(String timeSlot) {
        Button timeButton = new Button(this);
        timeButton.setText(timeSlot);
        timeButton.setTag(timeSlot);

        // Set button styling
        timeButton.setBackgroundResource(R.drawable.btn_bg);
        timeButton.setBackgroundTintList(getResources().getColorStateList(R.color.colorPrimary));
        timeButton.setTextColor(getResources().getColor(android.R.color.white));
        timeButton.setEnabled(true);

        timeButton.setPadding(16, 8, 16, 8);
        timeButton.setTextSize(12);

        // Set layout parameters
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(8, 8, 8, 8);
        timeButton.setLayoutParams(params);

        // Add click listener
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectTimeSlot(timeSlot, timeButton);
            }
        });

        timeSlotsLayout.addView(timeButton);
        timeSlotButtons.add(timeButton);
    }

    private void selectTimeSlot(String timeSlot, Button selectedButton) {
        // Reset all buttons to default state
        for (Button button : timeSlotButtons) {
            button.setBackgroundTintList(getResources().getColorStateList(R.color.colorPrimary));
        }

        // Highlight selected button
        selectedButton.setBackgroundTintList(getResources().getColorStateList(R.color.colorAccent));
        selectedTime = timeSlot;
        selectedTimeText.setText("Selected Time: " + timeSlot);
    }

    private void placeOrder() {
        try {
            String pname = patientName.getText().toString().trim();
            String page = patientAge.getText().toString().trim();
            String pphone = patientPhone.getText().toString().trim();
            String pgender = getSelectedGender();

            Log.d("LabTestBooking", "Patient: " + pname + ", Date: " + selectedDate + ", Time: " + selectedTime + ", Tests: " + cartItems.size());

            // Validation
            if (pname.isEmpty() || page.isEmpty() || pphone.isEmpty() || pgender.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields and select date/time", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isValidName(pname)) {
                patientName.setError("Please enter a valid name (2-30 characters, letters only)");
                return;
            }

            if (!isValidAge(page)) {
                patientAge.setError("Please enter a valid age (1-150)");
                return;
            }

            if (!isValidPhone(pphone)) {
                patientPhone.setError("Please enter a valid 10-digit phone number");
                return;
            }

            if (cartItems.isEmpty()) {
                Toast.makeText(this, "No tests selected", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get current user ID from session
            SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
            int currentUserId = sharedPreferences.getInt("user_id", -1);

            if (currentUserId == -1) {
                Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
                return;
            }

            // Place order with user ID, date, and time for ALL cart items
            boolean success = db.placeLabTestOrderWithDateTime(cartItems, pname, page, pgender, selectedDate, selectedTime, currentUserId);
            if (success) {
                // Clear cart for this user after successful booking
                db.clearCart(currentUserId);
                Toast.makeText(this, cartItems.size() + " lab test(s) booked successfully!", Toast.LENGTH_SHORT).show();

                // Go to Orders page
                Intent intent = new Intent(LabTestBookingActivity.this, OrdersActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to book lab tests", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("LabTestBooking", "Error booking lab tests: " + e.getMessage(), e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void goToMainMenu() {
        Intent intent = new Intent(LabTestBookingActivity.this, MainMenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    // Get selected gender from radio buttons
    private String getSelectedGender() {
        int selectedId = genderRadioGroup.getCheckedRadioButtonId();

        if (selectedId == R.id.maleRadio) {
            return "Male";
        } else if (selectedId == R.id.femaleRadio) {
            return "Female";
        } else if (selectedId == R.id.otherRadio) {
            return "Other";
        } else {
            return ""; // No gender selected
        }
    }

    // Validation methods
    private boolean isValidName(String name) {
        return name != null && NAME_PATTERN.matcher(name).matches();
    }

    private boolean isValidAge(String age) {
        return age != null && AGE_PATTERN.matcher(age).matches();
    }

    private boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone).matches();
    }
}