package com.example.healthasistence.doctors;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;

import java.util.ArrayList;

public class DoctorsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<DoctorModel> doctorList;
    DoctorAdapter adapter;
    ImageView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors);

        // Initialize views
        recyclerView = findViewById(R.id.doctorsRecycler);
        backBtn = findViewById(R.id.backBtn);

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Sample doctors data
        doctorList = new ArrayList<>();
        doctorList.add(new DoctorModel("Dr. Rahul Sharma", "Cardiologist", "10 years experience", "500", R.drawable.cardiologists));
        doctorList.add(new DoctorModel("Dr. Priya Mehta", "Dermatologist", "7 years experience", "400", R.drawable.dermatologist));
        doctorList.add(new DoctorModel("Dr. Arjun Verma", "Dentist", "5 years experience", "350", R.drawable.dentist));
        doctorList.add(new DoctorModel("Dr. Anjali Patel", "Pediatrician", "8 years experience", "450", R.drawable.pediatricia));
        doctorList.add(new DoctorModel("Dr. Sanjay Kumar", "Orthopedic", "12 years experience", "600", R.drawable.orthopedic));
        doctorList.add(new DoctorModel("Dr. Neha Singh", "Gynecologist", "9 years experience", "550", R.drawable.gynecologist));

        adapter = new DoctorAdapter(this, doctorList);
        recyclerView.setAdapter(adapter);
    }
}