package com.example.healthasistence.articles;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthasistence.R;

public class ArticleDetailActivity extends AppCompatActivity {

    TextView detailTitle, articleContent;
    ImageView detailImage, backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_detail);

        // Initialize views
        detailTitle = findViewById(R.id.detailTitle);
        detailImage = findViewById(R.id.detailImage);
        articleContent = findViewById(R.id.articleContent);
        backBtn = findViewById(R.id.backBtn);

        // Get article data from intent
        String title = getIntent().getStringExtra("title");
        String imageName = getIntent().getStringExtra("image");

        // Set values
        detailTitle.setText(title);

        // Set dynamic content based on title
        setArticleContent(title);

        // Set image based on image name
        int imageResource = getImageResource(imageName);
        detailImage.setImageResource(imageResource);

        // Back button click
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private int getImageResource(String imageName) {
        if (imageName == null) {
            return R.drawable.health1;
        }

        switch (imageName) {
            case "benefits":
                return R.drawable.benefits;
            case "healthy":
                return R.drawable.healthy;
            case "managing":
                return R.drawable.managing;
            case "importance":
                return R.drawable.importance;
            case "hearthealth":
                return R.drawable.hearthealth;
            case "mental":
                return R.drawable.mental;
            case "daily":
                return R.drawable.daily;
            case "nutrition":
                return R.drawable.nutrition;
            default:
                return R.drawable.health1;
        }
    }

    private void setArticleContent(String title) {
        String content = "";

        if (title.equals("Benefits of Regular Exercise")) {
            content = "Regular exercise is one of the most important things you can do for your health. It has numerous benefits including:\n\n- Improved cardiovascular health and reduced risk of heart disease\n- Better weight management and metabolism\n- Enhanced mental health and reduced symptoms of depression\n- Increased energy levels throughout the day\n- Stronger bones and muscles\n- Better sleep quality and patterns\n\nAim for at least 30 minutes of moderate exercise most days of the week for optimal benefits.";
        } else if (title.equals("Healthy Eating Habits")) {
            content = "Developing healthy eating habits is crucial for maintaining good health and preventing chronic diseases. Key principles include:\n\n- Eat a variety of fruits and vegetables daily\n- Choose whole grains over refined grains\n- Include lean protein sources in your diet\n- Limit processed foods and added sugars\n- Stay hydrated with water throughout the day\n- Practice portion control and mindful eating\n- Plan your meals ahead for better choices\n\nRemember, small consistent changes in your diet can lead to significant long-term health improvements.";
        } else if (title.equals("Managing Stress Effectively")) {
            content = "Stress management is essential for both mental and physical well-being. Effective strategies include:\n\n- Practice deep breathing exercises and meditation\n- Engage in regular physical activity\n- Maintain a healthy work-life balance\n- Get adequate sleep (7-9 hours per night)\n- Connect with friends and family for support\n- Limit caffeine and alcohol consumption\n- Learn to say no to unnecessary commitments\n- Take regular breaks during work hours\n\nIf stress becomes overwhelming, do not hesitate to seek professional help from a mental health provider.";
        } else if (title.equals("Importance of Sleep")) {
            content = "Quality sleep is fundamental to good health and well-being. Benefits of proper sleep include:\n\n- Enhanced memory and cognitive function\n- Improved immune system performance\n- Better mood and emotional regulation\n- Reduced risk of chronic diseases\n- Increased productivity and concentration\n- Healthy weight maintenance\n- Better physical performance and recovery\n\nTips for better sleep:\n- Maintain a consistent sleep schedule\n- Create a relaxing bedtime routine\n- Keep your bedroom dark, quiet, and cool\n- Avoid screens before bedtime\n- Limit caffeine in the evening";
        } else if (title.equals("Heart Health Tips")) {
            content = "Maintaining heart health should be a priority for everyone. Key recommendations include:\n\n- Eat a heart-healthy diet rich in fruits, vegetables, and whole grains\n- Exercise regularly (150 minutes of moderate activity per week)\n- Maintain a healthy weight\n- Do not smoke or use tobacco products\n- Limit alcohol consumption\n- Manage stress effectively\n- Get regular health check-ups\n- Monitor blood pressure and cholesterol levels\n- Know your family history of heart disease\n\nSmall lifestyle changes can significantly reduce your risk of heart disease and improve overall cardiovascular health.";
        } else if (title.equals("Mental Wellness Guide")) {
            content = "Mental wellness is just as important as physical health. Key aspects include:\n\n- Practice mindfulness and meditation regularly\n- Maintain social connections with friends and family\n- Engage in activities you enjoy\n- Seek professional help when needed\n- Practice gratitude and positive thinking\n- Set realistic goals and expectations\n- Take breaks and practice self-care\n- Learn healthy coping mechanisms for stress";
        } else if (title.equals("Daily Fitness Routine")) {
            content = "Establishing a daily fitness routine can transform your health. Consider these elements:\n\n- Start with 10-15 minutes of light cardio\n- Include strength training 2-3 times per week\n- Incorporate flexibility exercises like yoga or stretching\n- Take walking breaks throughout the day\n- Stay consistent with your routine\n- Listen to your body and rest when needed\n- Mix up your workouts to prevent boredom\n- Set achievable fitness goals";
        } else if (title.equals("Nutrition for All Ages")) {
            content = "Nutritional needs change throughout life. Key considerations:\n\n- Children: Focus on growth and development nutrients\n- Teens: Support rapid growth with balanced meals\n- Adults: Maintain health and prevent chronic diseases\n- Seniors: Focus on bone health and nutrient absorption\n- Include calcium-rich foods for bone health\n- Ensure adequate protein intake\n- Stay hydrated throughout the day\n- Consider vitamin and mineral supplements if needed";
        } else {
            content = "This comprehensive article provides valuable insights into maintaining good health and wellness. It covers essential aspects of daily life that contribute to overall well-being.\n\nKey Points:\n- Regular physical activity improves cardiovascular health\n- Balanced nutrition supports immune system\n- Adequate sleep enhances mental clarity\n- Stress management techniques for better mental health\n- Importance of regular health check-ups\n\nRemember that small, consistent changes in your daily routine can lead to significant improvements in your long-term health outcomes. Always consult healthcare professionals for personalized medical advice.";
        }

        articleContent.setText(content);
    }
}