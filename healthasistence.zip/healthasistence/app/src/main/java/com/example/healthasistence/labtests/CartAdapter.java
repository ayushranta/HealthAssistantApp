package com.example.healthasistence.labtests;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthasistence.R;
import com.example.healthasistence.database.DBHelper;

import java.util.ArrayList;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    Context context;
    ArrayList<LabTestModel> list;
    DBHelper db;

    public CartAdapter(Context context, ArrayList<LabTestModel> list) {
        this.context = context;
        this.list = list;
        db = new DBHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LabTestModel model = list.get(position);

        holder.name.setText(model.getName());
        holder.description.setText(model.getDescription());
        holder.price.setText("₹" + model.getPrice());

        // Remove button click
        holder.removeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Remove item from cart
                boolean removed = removeFromCart(model.getName());
                if (removed) {
                    // Remove from list and update UI
                    list.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, list.size());

                    // Refresh cart in activity
                    if (context instanceof CartActivity) {
                        ((CartActivity) context).refreshCart();
                    }

                    Toast.makeText(context, "Removed from cart", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean removeFromCart(String testName) {
        // This method should be implemented in DBHelper
        // For now, we'll clear and re-add all items except the one to remove
        SQLiteDatabase db = this.db.getWritableDatabase();
        int result = db.delete("cart", "testName=?", new String[]{testName});
        return result > 0;
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, description, price;
        ImageView removeBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.cartTestName);
            description = itemView.findViewById(R.id.cartTestDescription);
            price = itemView.findViewById(R.id.cartTestPrice);
            removeBtn = itemView.findViewById(R.id.removeBtn);
        }
    }
}