package com.example.healthasistence.orders;

public class OrderModel {
    String type, patientName, doctorName, specialization, fee, date, time;

    // Constructor for appointments
    public OrderModel(String type, String patientName, String doctorName, String specialization,
                      String fee, String date, String time) {
        this.type = type;
        this.patientName = patientName;
        this.doctorName = doctorName;
        this.specialization = specialization;
        this.fee = fee;
        this.date = date;
        this.time = time;
    }

    public String getType() { return type; }
    public String getPatientName() { return patientName; }
    public String getDoctorName() { return doctorName; }
    public String getSpecialization() { return specialization; }
    public String getFee() { return fee; }
    public String getDate() { return date; }
    public String getTime() { return time; }
}