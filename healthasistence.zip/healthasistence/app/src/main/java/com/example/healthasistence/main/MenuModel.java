package com.example.healthasistence.main;

public class MenuModel {
    private String title;
    private int icon;
    private Class<?> activityClass;

    public MenuModel(String title, int icon, Class<?> activityClass) {
        this.title = title;
        this.icon = icon;
        this.activityClass = activityClass;
    }

    public String getTitle() { return title; }
    public int getIcon() { return icon; }
    public Class<?> getActivityClass() { return activityClass; }
}